Install Instructions
1. Place this xltm file in this folder  C:\Users\%USERNAME%\Documents\Custom Office Templates\
2. Check File\Options\Save and make sure the default personal template location matches above

Usage Instruction
1. Open an instance of Power BI Desktop and a pbix file.  There must be 1 and only 1
2. Create a new workbook by selecting File\New\Personal and selecting the template


This file was developed and is distributed by Matt Allington 
1. Originally at this blog post http://exceleratorbi.com.au/excel-workbook-connection-local-power-bi-desktop/
2. And then updated to include Measures and Memory Usage
3. And then updated again to include Measure Dependencies

Potential Error 1
If you get a runtime error '1004', please check the privacy settings for the template as follows:
Read all steps before you start.

1. Open Excel
2. Navigate to Documents\Custom Office Templates\
3. Open the template workbook
4. Navigate to Data\Get Data\Query Options\Current Workbook\Privacy
5. Set the privacy levels to ignore
6. Save the template.  Note when prompted if you want clear the data before saving, select NO.

Potential Error 2
If you get a warning message "You must have exactly 1 instance of Power BI Desktop open", then the most likely cause
is that you have 2 instances of Power BI open.  Close the one that you don't want to use. If however you do actually
only have a single instance open already, then you should check to see if you have some temp files that were not deleted
correcty.  To do this
1. Go to the Connection Tab
2. Click the button "Open Folder"
3. If there is more than 1 folder visible, delete the one(s) not associated with the current open Power BI Desktop file
   using the creation date as the reference. 

Version 6.3 27 Sep 2018
Improved common error message to make it clearer how to solve the issue.

Version 5.2 29 Nov 2017
Microsoft is always changing Power BI Desktop.  Sometimes when it makes changes, this workbook stops working.  I added a measures dependency feature earlier in 2017 and this is currently not working.  I have added a new version of the workbook called 
Local Host Workbook - no dependencies.xlsm
This version works. I have left the other version in and it may start working again in the future, and/or I may update it again in the future.  For now, please use  the version mentioned above if you want to extract measures.

Version 5.1
This Local Host Workbook is designed to connect to a data model running in an instance of Power BI Desktop on your PC.

Update: 27 Oct 2017
Microsoft now has an App Store version of Power BI Desktop. If you use the App Store version, you must use the Store version of this template.  Both the Store version and original version are provided within.